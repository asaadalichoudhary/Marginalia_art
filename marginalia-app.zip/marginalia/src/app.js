(() => {
'use strict';

/* ═════════ small helpers ═════════ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const SVGNS = 'http://www.w3.org/2000/svg';
const el = (tag, props = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids) if (k != null) e.append(k);
  return e;
};
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const words = s => (s.match(/\S+/g) || []).length;
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const roman = n => { const m = [[1000,'M'],[900,'CM'],[500,'D'],[400,'CD'],[100,'C'],[90,'XC'],[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']]; let s = ''; for (const [v, r] of m) while (n >= v) { s += r; n -= v; } return s; };
const SWELL = '<svg class="swell" viewBox="0 0 140 12" aria-hidden="true"><path fill="currentColor" d="M0 6 C40 5 58 3.2 64 6 C58 8.8 40 7 0 6Z M140 6 C100 5 82 3.2 76 6 C82 8.8 100 7 140 6Z M70 1.5 L74.5 6 L70 10.5 L65.5 6Z"/></svg>';

/* ═════════ settings (per-viewer convenience → localStorage) ═════════ */
const FACES = {
  literata: "'Literata', 'Iowan Old Style', 'Palatino Linotype', Georgia, serif",
  caslon: "'Libre Caslon Text', 'Hoefler Text', Baskerville, Georgia, serif",
  atkinson: "'Atkinson Hyperlegible', Verdana, 'Segoe UI', sans-serif",
};
const S = { fs: '18', face: 'literata', tone: 'auto', density: '2', paused: '0',
  provider: 'cloudflare', cfUrl: '', cfKey: '', polKey: '', gemKey: '', gemText: 'gemini-2.5-flash', gemImage: 'gemini-2.5-flash-image', oaKey: '', oaText: 'gpt-4o-mini', oaImage: 'gpt-image-1' };
try { Object.assign(S, JSON.parse(localStorage.getItem('marginalia.settings') || '{}')); } catch {}
const saveSettings = () => { try { localStorage.setItem('marginalia.settings', JSON.stringify(S)); } catch {} };
function applySettings() {
  const root = document.documentElement;
  if (S.tone === 'auto') root.removeAttribute('data-tone'); else root.setAttribute('data-tone', S.tone);
  root.style.setProperty('--body-face', FACES[S.face] || FACES.literata);
}
applySettings();

/* ═════════ storage: IndexedDB with an in-memory fallback ═════════ */
const Store = (() => {
  let db = null;
  const mem = { metas: new Map(), books: new Map(), plates: new Map(), states: new Map() };
  const KEY = { metas: 'id', books: 'id', plates: 'id', states: 'bookId' };
  const open = () => new Promise(res => {
    try {
      const rq = indexedDB.open('marginalia', 1);
      rq.onupgradeneeded = () => { const d = rq.result;
        d.createObjectStore('metas', { keyPath: 'id' }); d.createObjectStore('books', { keyPath: 'id' });
        d.createObjectStore('plates', { keyPath: 'id' }).createIndex('book', 'bookId'); d.createObjectStore('states', { keyPath: 'bookId' }); };
      rq.onsuccess = () => { db = rq.result; res(); };
      rq.onerror = rq.onblocked = () => res();
    } catch { res(); }
  });
  const run = (store, mode, fn) => new Promise(res => {
    if (!db) return res(undefined);
    try { const t = db.transaction(store, mode); const r = fn(t.objectStore(store));
      t.oncomplete = () => res(r ? r.result : undefined); t.onerror = t.onabort = () => res(undefined); } catch { res(undefined); }
  });
  return {
    open,
    async put(store, v) { mem[store].set(v[KEY[store]], v); await run(store, 'readwrite', s => s.put(v)); },
    async get(store, k) { const v = await run(store, 'readonly', s => s.get(k)); return v ?? mem[store].get(k); },
    async all(store) { const v = await run(store, 'readonly', s => s.getAll()); return v && v.length ? v : [...mem[store].values()]; },
    async platesOf(bookId) { const v = await run('plates', 'readonly', s => s.index('book').getAll(bookId)); return v && v.length ? v : [...mem.plates.values()].filter(p => p.bookId === bookId); },
    async del(store, k) { mem[store].delete(k); await run(store, 'readwrite', s => s.delete(k)); },
  };
})();

/* ═════════ PDF → book ═════════ */
const HEAD_RE = /^(chapter|book|part|volume|letter|act|stave|section)\s+([ivxlcdm]+|\d+|[a-z]+(?:[-\s][a-z]+)?)\b[.:]?(.{0,60})$/i;
const HEAD_WORD_RE = /^(prologue|epilogue|preface|introduction|foreword|afterword|interlude|prelude|postscript)\b.{0,40}$/i;
const HEAD_NUM_RE = /^(?:[IVXLC]{1,7}|\d{1,3})\.?$/;
const BREAK_RE = /^(?:[*#~•·◆❦⁂]\s*){1,7}$|^[-–—_]{3,}$|^(?:[-–—]\s+){2,}[-–—]$/;
const TERMINAL_RE = /[.!?…:;"”’')\]—–-]$/;

function toLines(items) {
  const lines = []; let cur = null;
  for (const it of items) {
    if (typeof it.str !== 'string') continue;
    const [a, b, c, d, x, y] = it.transform;
    if (Math.abs(b) > Math.abs(a) * 0.3) continue;                       // rotated watermark text
    const size = Math.hypot(c, d) || it.height || 10;
    if (!it.str.trim() && !cur) continue;
    if (cur && Math.abs(y - cur.y) <= Math.max(2, cur.size * 0.45) && x >= cur.x0 - 2) {
      const gap = x - cur.x1;
      if (gap > cur.size * 0.18 && !/\s$/.test(cur.text) && !/^\s/.test(it.str)) cur.text += ' ';
      cur.text += it.str; cur.x1 = Math.max(cur.x1, x + it.width);
      if (it.str.trim().length > 3) cur.size = Math.max(cur.size, size);
    } else {
      if (cur) lines.push(cur);
      cur = { text: it.str, x0: x, x1: x + it.width, y, size };
    }
    if (it.hasEOL && cur) { lines.push(cur); cur = null; }
  }
  if (cur) lines.push(cur);
  return lines.map(l => ({ ...l, text: l.text.replace(/\s+/g, ' ').trim() })).filter(l => l.text).sort((p, q) => q.y - p.y);
}

function smarten(s) {
  return s.replace(/(\w)-\s?-(\w)/g, '$1—$2').replace(/\s--\s/g, ' — ').replace(/--/g, '—')
    .replace(/(^|[\s(\[{—–-])"/g, '$1“').replace(/"/g, '”')
    .replace(/(^|[\s(\[{—–“-])'/g, '$1‘').replace(/'/g, '’')
    .replace(/\.\.\./g, '…');
}

async function extractBook(file, onProgress) {
  if (!window.pdfjsLib) throw new Error('The PDF reader could not load. Check your connection and reload this page.');
  const data = new Uint8Array(await file.arrayBuffer());
  let pdf;
  try { pdf = await pdfjsLib.getDocument({ data, isEvalSupported: false, disableFontFace: true, useSystemFonts: false }).promise; }
  catch (e) { throw new Error(e && e.name === 'PasswordException' ? 'This PDF is password-protected. Remove the password and open it again.' : 'This file could not be read as a PDF.'); }
  let info = {}; try { info = (await pdf.getMetadata()).info || {}; } catch {}
  const pages = [];
  for (let n = 1; n <= pdf.numPages; n++) {
    const page = await pdf.getPage(n);
    const vp = page.getViewport({ scale: 1 });
    const tc = await page.getTextContent();
    pages.push({ h: vp.height, w: vp.width, lines: toLines(tc.items) });
    page.cleanup();
    onProgress(n, pdf.numPages);
    if (n % 6 === 0) await new Promise(r => setTimeout(r));
  }
  try { pdf.destroy(); } catch {}
  const chars = pages.reduce((s, p) => s + p.lines.reduce((t, l) => t + l.text.length, 0), 0);
  if (chars < 1500) throw new Error('This PDF has no selectable text. It looks like scanned images; run it through OCR first, then open it again.');

  /* running heads, folios */
  const norm = t => t.toLowerCase().replace(/\d+/g, '#').replace(/\s+/g, ' ').trim();
  const freq = new Map(), offs = new Map();
  pages.forEach((p, i) => {
    const cands = p.lines.length > 1 ? [p.lines[0], p.lines[p.lines.length - 1]] : p.lines.slice(0, 1);
    for (const l of cands) {
      const k = norm(l.text); freq.set(k, (freq.get(k) || 0) + 1);
      const m = l.text.match(/^\D{0,3}(\d{1,4})\D{0,3}$/); if (m) { const o = +m[1] - i; offs.set(o, (offs.get(o) || 0) + 1); }
    }
  });
  const repeatMin = Math.max(3, pages.length * 0.12);
  const folioOffsets = new Set([...offs].filter(([, c]) => c >= 3).map(([o]) => o));
  pages.forEach((p, i) => {
    const isFurniture = (l, edge) => {
      if (!l) return false;
      const m = l.text.match(/^\D{0,3}(\d{1,4})\D{0,3}$/);
      if (m && folioOffsets.has(+m[1] - i)) return true;
      if (/^[ivxlc]{1,6}$/i.test(l.text) && (l.y < p.h * 0.1 || l.y > p.h * 0.9) && l.text === l.text.toLowerCase()) return true;
      if (l.text.length < 90 && freq.get(norm(l.text)) >= repeatMin && (edge || true)) return true;
      return false;
    };
    if (isFurniture(p.lines[0])) p.lines.shift();
    if (isFurniture(p.lines[p.lines.length - 1])) p.lines.pop();
    if (isFurniture(p.lines[0])) p.lines.shift();
  });

  /* body metrics */
  const sizeTally = new Map();
  for (const p of pages) for (const l of p.lines) { const k = Math.round(l.size * 2) / 2; sizeTally.set(k, (sizeTally.get(k) || 0) + l.text.length); }
  const body = [...sizeTally].sort((a, b) => b[1] - a[1])[0][0];
  const gaps = [];
  for (const p of pages) for (let i = 1; i < p.lines.length; i++) { const g = p.lines[i - 1].y - p.lines[i].y; if (g > body * 0.6 && g < body * 3) gaps.push(g); }
  gaps.sort((a, b) => a - b);
  const lineGap = gaps.length ? gaps[Math.floor(gaps.length * 0.4)] : body * 1.3;

  /* lines → blocks */
  const blocks = []; let cur = null, prev = null, prevPage = -1, prevIndented = false;
  const push = () => { if (cur) { blocks.push(cur); cur = null; } };
  pages.forEach((p, pi) => {
    const bodyLines = p.lines.filter(l => Math.abs(l.size - body) < 1.2 && l.text.length > 25);
    const tally = new Map(); for (const l of bodyLines) { const k = Math.round(l.x0); tally.set(k, (tally.get(k) || 0) + 1); }
    const left = tally.size ? [...tally].sort((a, b) => b[1] - a[1] || a[0] - b[0])[0][0] : Math.min(...p.lines.map(l => l.x0), 72);
    const right = bodyLines.length ? Math.max(...bodyLines.map(l => l.x1)) : p.w - left;
    for (let li = 0; li < p.lines.length; li++) {
      const l = p.lines[li], t = l.text;
      // a dropped capital set as its own oversized item: glue it to the next line
      if (t.length <= 2 && /^[“"‘']?[A-Z]$/.test(t) && l.size > body * 1.5 && p.lines[li + 1]) { p.lines[li + 1] = { ...p.lines[li + 1], text: t + p.lines[li + 1].text, x0: left }; continue; }
      const samePage = prevPage === pi;
      const gap = samePage && prev ? prev.y - l.y : 0;
      const indented = l.x0 - left > body * 0.8;
      const short = prev ? prev.x1 < prev.right - body * 2.5 : false;
      const isBreak = BREAK_RE.test(t);
      const isHead = t.length < 72 && (HEAD_RE.test(t) || HEAD_WORD_RE.test(t) || (l.size > body * 1.28 && t.length < 64 && /[A-Za-z]/.test(t)) ||
        (HEAD_NUM_RE.test(t) && (!samePage || gap > lineGap * 1.7 || li === 0)));
      if (isBreak) { push(); blocks.push({ k: 'br' }); }
      else if (isHead) {
        push();
        const last = blocks[blocks.length - 1];
        if (last && last.k === 'h' && !last.title) last.title = t; else blocks.push({ k: 'h', label: t, title: '' });
      } else {
        const last = blocks[blocks.length - 1];
        const titleLine = !cur && last && last.k === 'h' && !last.title && t.length < 60 && l.x1 < right - body * 3 && !/[.!?,;:"”’]$/.test(t) && (HEAD_RE.test(last.label) || HEAD_NUM_RE.test(last.label));
        if (titleLine) { last.title = t; }
        else {
          let fresh = !cur;
          if (cur) {
            if (samePage && gap > lineGap * 1.45) fresh = true;
            else if (indented && !prevIndented) fresh = true;
            else if (short && TERMINAL_RE.test(prev.text)) fresh = true;
          }
          if (fresh) {
            const sceneGap = cur && samePage && gap > lineGap * 2.7;
            push(); if (sceneGap) blocks.push({ k: 'br' });
            cur = { k: 'p', x: t };
          } else {
            if (/[A-Za-z]-$/.test(cur.x) && /^[a-z]/.test(t)) cur.x = cur.x.slice(0, -1) + t;
            else cur.x += ' ' + t;
          }
        }
      }
      prev = { ...l, right }; prevPage = pi; prevIndented = indented;
    }
  });
  push();

  /* blocks → sections */
  let sections = [], sec = { label: '', title: '', paras: [] }, part = '';
  const close = () => {
    const w = sec.paras.reduce((s, p) => s + (p.k === 'p' ? words(p.x) : 0), 0);
    if (w >= 25) { while (sec.paras.length && sec.paras[sec.paras.length - 1].k === 'br') sec.paras.pop(); sections.push(sec); }
    else if (/^(part|book|volume)\b/i.test(sec.label)) part = [sec.label, sec.title].filter(Boolean).join(': ');
  };
  for (const b of blocks) {
    if (b.k === 'h') { close(); sec = { label: smarten(b.label), title: smarten(b.title), paras: [] }; if (part) { sec.part = part; part = ''; } }
    else if (b.k === 'br') { if (sec.paras.length && sec.paras[sec.paras.length - 1].k !== 'br') sec.paras.push({ k: 'br' }); }
    else sec.paras.push({ k: 'p', x: smarten(b.x) });
  }
  close();
  if (!sections.length) throw new Error('No readable prose was found in this PDF.');
  // a book with no chapter headings: cut into sittings of about 5,000 words
  if (sections.length === 1 && sections[0].paras.length > 60) {
    const all = sections[0].paras; sections = []; let bucket = [], w = 0;
    for (const p of all) { bucket.push(p); w += p.k === 'p' ? words(p.x) : 0; if (w >= 5000) { sections.push({ label: '', title: '', paras: bucket, auto: true }); bucket = []; w = 0; } }
    if (bucket.length) { if (w < 1200 && sections.length) sections[sections.length - 1].paras.push(...bucket); else sections.push({ label: '', title: '', paras: bucket, auto: true }); }
  }
  // all-caps chapter labels read as shouting once reset in small caps
  for (const s of sections) {
    if (s.label && s.label === s.label.toUpperCase()) s.label = s.label.replace(/\w\S*/g, w => /^[IVXLCDM]+\.?$/.test(w) ? w : w[0] + w.slice(1).toLowerCase());
    if (s.title && s.title === s.title.toUpperCase() && s.title.length > 3) s.title = s.title.toLowerCase().replace(/(^|\s|[-—“‘])([a-z])/g, (m, a, c) => a + c.toUpperCase());
    if (!s.title && s.label && !HEAD_RE.test(s.label) && !HEAD_NUM_RE.test(s.label) && !HEAD_WORD_RE.test(s.label)) { s.title = s.label; s.label = ''; }
  }
  const clean = v => (typeof v === 'string' ? v.replace(/\s+/g, ' ').trim() : '');
  let title = clean(info.Title), author = clean(info.Author);
  if (!title || /^(untitled|microsoft word|document\d*|.*\.(docx?|pdf|indd|qxd|tex))$/i.test(title)) title = file.name.replace(/\.pdf$/i, '').replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (/^(unknown|user|admin|owner|calibre)$/i.test(author)) author = '';
  return { id: uid(), title: smarten(title), author, addedAt: Date.now(), seed: Math.floor(Math.random() * 2e9) + 1, sections };
}

/* derived indices (never stored) */
function indexBook(book) {
  let total = 0;
  book.sections.forEach((s, si) => {
    s.start = total; s.cum = []; let w = 0;
    s.paras.forEach(p => { s.cum.push(w); if (p.k === 'p') w += words(p.x); });
    s.words = w; total += w;
    // planning windows: about 3,000 words each
    s.windows = []; let from = 0, acc = 0;
    s.paras.forEach((p, i) => { acc += p.k === 'p' ? words(p.x) : 0; if (acc >= 3000) { s.windows.push({ sec: si, from, to: i, words: acc }); from = i + 1; acc = 0; } });
    if (from < s.paras.length) { const lastW = s.windows[s.windows.length - 1]; if (acc < 900 && lastW) { lastW.to = s.paras.length - 1; lastW.words += acc; } else s.windows.push({ sec: si, from, to: s.paras.length - 1, words: acc }); }
    s.windows.forEach((w2, wi) => { w2.idx = wi; w2.startWord = s.start + s.cum[w2.from]; });
  });
  book.totalWords = total;
}
const secName = (s, i) => s.title || s.label || (s.auto ? 'Part ' + roman(i + 1) : 'Opening pages');

/* ═════════ SVG: sanitising and the pencil treatment ═════════ */
const HATCHES = new Set(['h1', 'h2', 'h3', 'h4', 'hv', 'hh', 'hc', 'st']);
const NAMED = { black: 0, white: 1, gray: .5, grey: .5, dimgray: .41, dimgrey: .41, darkgray: .66, darkgrey: .66, silver: .75, lightgray: .83, lightgrey: .83, gainsboro: .86, whitesmoke: .96, ivory: .99, snow: .99, beige: .94, currentcolor: 0 };
function luminance(v) {
  let m;
  if ((m = v.match(/^#([0-9a-f]{3,8})$/i))) { let h = m[1]; if (h.length <= 4) h = [...h].slice(0, 3).map(c => c + c).join(''); const [r, g, b] = [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16) / 255); return .2126 * r + .7152 * g + .0722 * b; }
  if ((m = v.match(/^rgba?\(\s*([\d.]+)(%?)[\s,]+([\d.]+)%?[\s,]+([\d.]+)%?/i))) { const k = m[2] ? 100 : 255; return (.2126 * m[1] + .7152 * m[3] + .0722 * m[4]) / k; }
  if ((m = v.match(/^hsla?\(\s*[\d.]+\w*[\s,]+[\d.]+%[\s,]+([\d.]+)%/i))) return +m[1] / 100;
  return v in NAMED ? NAMED[v] : .25;
}
const toneOf = L => L < .2 ? '0' : L < .4 ? '1' : L < .6 ? '2' : L < .86 ? '3' : 'p';
const NUM_ATTRS = new Set(['x', 'y', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy', 'r', 'rx', 'ry', 'width', 'height', 'opacity', 'fill-opacity', 'stroke-opacity', 'stroke-width', 'stroke-miterlimit', 'stroke-dashoffset']);
const SHAPES = new Set(['g', 'path', 'line', 'polyline', 'polygon', 'circle', 'ellipse', 'rect']);

/* Take untrusted SVG text; return clean inner markup (string) plus an element count, or null. */
function sanitizeSvg(text, kind) {
  const W = 600, H = kind === 'full' ? 800 : 400;
  const src = text.replace(/<!--[\s\S]*?-->/g, '').replace(/<\?[\s\S]*?\?>/g, '').replace(/<!DOCTYPE[^>]*>/gi, '');
  let doc; try { doc = new DOMParser().parseFromString(src, 'image/svg+xml'); } catch { return null; }
  const root = doc.documentElement;
  if (!root || root.nodeName.toLowerCase() !== 'svg' || doc.getElementsByTagName('parsererror').length) return null;
  let count = 0;
  const out = document.createElementNS(SVGNS, 'g');
  const walk = (node, into, depth) => {
    for (const c of node.children) {
      const tag = c.localName;
      if (!SHAPES.has(tag) || depth > 12 || count > 1600) continue;
      if (tag === 'rect') { const w = parseFloat(c.getAttribute('width')), hh = parseFloat(c.getAttribute('height')); const f = (c.getAttribute('fill') || '').trim().toLowerCase();
        if ((w >= W * .93 || /%/.test(c.getAttribute('width') || '')) && (hh >= H * .93 || /%/.test(c.getAttribute('height') || '')) && !/^url/.test(f)) continue; }   // full-canvas backdrop
      const e = document.createElementNS(SVGNS, tag); const cls = [];
      for (const { name, value } of [...c.attributes]) {
        const v = value.trim(); if (!v || v.length > 60000) continue;
        if (name === 'fill' || name === 'stroke') {
          const lv = v.toLowerCase(); let m;
          if (lv === 'none' || lv === 'transparent') e.setAttribute(name, 'none');
          else if ((m = lv.match(/^url\(\s*['"]?#([a-z0-9]+)['"]?\s*\)$/))) { if (HATCHES.has(m[1]) && name === 'fill') e.setAttribute('fill', `url(#${m[1]})`); else e.setAttribute(name, 'none'); }
          else cls.push((name === 'fill' ? 'f' : 's') + toneOf(luminance(lv)));
        } else if (name === 'd') { if (/^[\dMmLlHhVvCcSsQqTtAaZz\s,.\-+eE]+$/.test(v)) e.setAttribute('d', v); }
        else if (name === 'points') { if (/^[\d\s,.\-+eE]+$/.test(v)) e.setAttribute('points', v); }
        else if (name === 'transform') { if (/^[a-zA-Z\d\s,.\-+()]+$/.test(v) && v.length < 200) e.setAttribute('transform', v); }
        else if (NUM_ATTRS.has(name)) { if (/^-?[\d.]+(e-?\d+)?%?$/i.test(v)) e.setAttribute(name, v); }
        else if (name === 'stroke-linecap') { if (/^(round|butt|square)$/.test(v)) e.setAttribute(name, v); }
        else if (name === 'stroke-linejoin') { if (/^(round|bevel|miter)$/.test(v)) e.setAttribute(name, v); }
        else if (name === 'fill-rule') { if (/^(evenodd|nonzero)$/.test(v)) e.setAttribute(name, v); }
        else if (name === 'stroke-dasharray') { if (/^[\d\s,.]+$/.test(v)) e.setAttribute(name, v); }
      }
      if (cls.length) e.setAttribute('class', cls.join(' '));
      if (tag === 'g') walk(c, e, depth + 1); else count++;
      if (tag !== 'g' || e.childNodes.length) into.append(e);
    }
  };
  walk(root, out, 0);
  return count ? { markup: out.innerHTML, count } : null;
}

function plateSvg(markup, kind, label) {
  const svg = document.createElementNS(SVGNS, 'svg');
  svg.setAttribute('viewBox', kind === 'full' ? '0 0 600 800' : '0 0 600 400');
  svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', label || 'Illustration');
  svg.innerHTML = `<g mask="url(#vig-${kind === 'full' ? 'full' : 'inset'})"><g class="ink" fill="none" stroke-linecap="round" stroke-linejoin="round" filter="url(#pencil)">${markup || ''}</g><g class="ghost" fill="none" stroke-linecap="round" stroke-linejoin="round" filter="url(#pencil-b)">${markup || ''}</g></g>`;
  return svg;
}

/* ═════════ the reader ═════════ */
const R = { book: null, state: null, plates: new Map(), sec: 0, view: 0, views: 1, cols: 1, per: 1, colW: 0, gap: 0, pageH: 0, lh: 28, paraEls: [], knownCols: new Map(), fullCols: new Set() };
const flow = $('#flow'), bookEl = $('#book'), clip = $('#clip');
const RS = () => R.book.sections;           // real sections; index -1 is the title page
const SEC_TITLE = -1;

function geometry() {
  const desk = $('#desk'); const aw = desk.clientWidth, ah = desk.clientHeight;
  const fs = +S.fs, lh = Math.round(fs * 1.56);
  const spread = aw >= 900 && aw / ah > 1.15;
  let bw, bh;
  if (spread) { bh = Math.min(ah - 20, (aw - 40) / 1.36, 1000); bw = bh * 1.36; }
  else { bw = Math.min(aw, 640); bh = aw > 640 ? ah - 20 : ah; }
  bw = Math.floor(bw); bh = Math.floor(bh);
  const pageW = spread ? bw / 2 : bw;
  const outer = spread ? pageW * .115 : Math.max(22, pageW * .085);
  const inner = spread ? pageW * .105 : outer;
  const top = Math.max(lh * 2.3, bh * .07), bottom = Math.max(lh * 2.3, bh * .075);
  const pageH = Math.floor((bh - top - bottom) / lh) * lh;
  const clipW = Math.floor(bw - 2 * outer);
  const gap = spread ? Math.round(2 * inner) : Math.round(2 * outer);
  const colW = spread ? (clipW - gap) / 2 : clipW;
  Object.assign(R, { spread, per: spread ? 2 : 1, colW, gap, pageH, lh, clipW, geoKey: [bw, bh, fs, S.face].join('|') });
  bookEl.classList.toggle('spread', spread);
  bookEl.style.width = bw + 'px'; bookEl.style.height = bh + 'px';
  const root = document.documentElement.style;
  root.setProperty('--fs', fs + 'px'); root.setProperty('--lh', lh + 'px'); root.setProperty('--page-h', pageH + 'px');
  Object.assign(clip.style, { left: outer + 'px', top: top + 'px', width: clipW + 'px', height: pageH + 'px' });
  Object.assign(flow.style, { width: clipW + 'px', height: pageH + 'px', columnCount: R.per, columnGap: gap + 'px' });
  const headY = top - lh * 1.45, folioY = top + pageH + lh * .55;
  const place = (node, side, y) => Object.assign(node.style, { top: y + 'px', left: (side === 'L' ? outer : outer + colW + gap) + 'px', width: colW + 'px' });
  place($('#headL'), 'L', headY); place($('#folioL'), 'L', folioY);
  place($('#headR'), spread ? 'R' : 'L', headY); place($('#folioR'), spread ? 'R' : 'L', folioY);
}

function buildSection(si) {
  flow.textContent = ''; R.paraEls = [];
  const b = R.book;
  if (si === SEC_TITLE) {
    if (R.spread) flow.append(el('div', { class: 'blank' }));
    const tp = el('div', { class: 'tpage' },
      el('div', { class: 'top' }), el('div', { class: 'tt', text: b.title }));
    tp.insertAdjacentHTML('beforeend', SWELL);
    if (b.author) tp.append(el('div', { class: 'au', text: b.author }));
    tp.append(el('p', { class: 'note', text: 'With plates in pencil, drawn as the pages are turned.' }));
    tp.append(el('div', { class: 'ed', text: 'Marginalia Edition' }));
    flow.append(tp);
    return;
  }
  const s = RS()[si];
  if (s.label || s.title || s.part) {
    const head = el('div', { class: 'chead' + (s.label || s.part ? '' : ' nolab') });
    if (s.part) head.append(el('div', { class: 'lab', text: s.part }));
    if (s.label) head.append(el('div', { class: 'lab', text: s.label }));
    if (s.title) head.append(el('div', { class: 'ttl', text: s.title }));
    head.insertAdjacentHTML('beforeend', SWELL);
    flow.append(head);
  }
  let first = !!(s.label || s.title) || si === 0;
  const frag = document.createDocumentFragment();
  s.paras.forEach((p, i) => {
    let e;
    if (p.k === 'br') e = el('div', { class: 'br', 'data-i': i, text: '***', 'aria-hidden': 'true' });
    else { e = el('p', { 'data-i': i, text: p.x }); if (first) { e.className = 'first'; first = false; } }
    R.paraEls[i] = e; frag.append(e);
  });
  flow.append(frag);
}

const platesIn = si => [...R.plates.values()].filter(p => p.sec === si && p.status !== 'removed').sort((a, b) => a.para - b.para);

function plateEl(pl) {
  const fig = el('figure', { class: `plate ${pl.kind} ${pl.status === 'done' ? 'done' : ''}`, 'data-plate': pl.id, tabindex: '0' });
  const art = el('div', { class: 'art' });
  if (pl.status === 'done' && pl.img) art.append(el('img', { src: urlOf(pl), alt: pl.caption, draggable: 'false' }));
  art.append(el('div', { class: 'wip' }));
  fig.append(art, el('figcaption', { text: '“' + pl.caption + '”' }));
  paintWip(fig, pl);
  return fig;
}
function paintWip(fig, pl) {
  const wip = $('.wip', fig); if (!wip) return;
  fig.classList.toggle('done', pl.status === 'done');
  wip.textContent = '';
  if (pl.status === 'done') return;
  if (pl.status === 'failed') {
    wip.append(el('span', { text: 'This plate did not come out.' }),
      el('button', { type: 'button', text: 'Draw it again', onclick: e => { e.stopPropagation(); redraw(pl.id); } }),
      el('button', { type: 'button', text: 'Remove the plate', onclick: e => { e.stopPropagation(); removePlate(pl.id); } }));
    return;
  }
  wip.insertAdjacentHTML('beforeend', '<svg class="pencil" viewBox="0 0 64 10" aria-hidden="true"><path d="M2 6 C10 1 14 9 22 5 S34 2 42 6 S56 8 62 3"/></svg>');
  wip.append(el('span', { text: pl.status === 'drawing' ? 'The pencil is on this plate now' : 'A plate is planned for this page' }));
}

function placePlates() {
  $$('.plate', flow).forEach(f => f.remove());
  $$('p.cont', flow).forEach(p => p.classList.remove('cont'));
  const list = platesIn(R.sec); if (!list.length) return;
  const n = R.paraEls.length;
  for (const pl of list) {
    const fig = plateEl(pl);
    const bottom = flow.getBoundingClientRect().top + R.pageH;
    const need = pl.kind === 'full' ? Infinity : R.colW * 2 / 3 + R.lh * 3;
    let best = null, bestWaste = Infinity;
    for (let i = clamp(pl.para, 0, n - 1); i < Math.min(pl.para + 7, n); i++) {
      const e = R.paraEls[i]; if (!e || e.classList.contains('br')) continue;
      if (i < n - 1 && R.paraEls[i + 1] && R.paraEls[i + 1].classList.contains('br')) continue;
      const rs = e.getClientRects(); if (!rs.length) continue;
      const rem = bottom - rs[rs.length - 1].bottom;
      const waste = rem >= need ? 0 : rem;
      if (waste < bestWaste - .5) { bestWaste = waste; best = e; }
      if (waste <= R.lh * 1.1) break;
    }
    (best || R.paraEls[clamp(pl.para, 0, n - 1)]).after(fig);
    if (pl.kind === 'inset') {                  // keep the text below on the line grid so no page ends a line short
      const h = fig.getBoundingClientRect().height, mt = R.lh * .5;
      const total = Math.ceil((mt + h + R.lh * .35) / R.lh) * R.lh;
      fig.style.marginTop = mt + 'px'; fig.style.marginBottom = (total - mt - h) + 'px';
    }
  }
}

function measureCols() {
  const step = R.colW + R.gap, base = flow.getBoundingClientRect().left;
  let right = 1;
  const tail = flow.lastElementChild;
  if (tail) for (const r of tail.getClientRects()) right = Math.max(right, r.right - base);
  R.cols = Math.max(1, Math.floor((right - 2) / step) + 1);
  R.views = Math.ceil(R.cols / R.per);
  R.knownCols.set(R.geoKey + '#' + R.sec, R.cols);
  R.fullCols = new Set($$('.plate.full', flow).map(f => Math.round((f.getBoundingClientRect().left - base) / step)));
  if (R.sec === SEC_TITLE) for (let c = 0; c < R.cols; c++) R.fullCols.add(c);
}
const viewOfEl = (e, frag = 0) => { const base = flow.getBoundingClientRect().left; const rs = e.getClientRects(); const r = rs[Math.min(frag, rs.length - 1)]; return r ? Math.floor(Math.round((r.left - base) / (R.colW + R.gap)) / R.per) : 0; };

function anchorPara() {
  if (R.sec === SEC_TITLE) return { para: 0, frag: 0 };
  const c = clip.getBoundingClientRect();
  for (let i = 0; i < R.paraEls.length; i++) { const e = R.paraEls[i]; if (!e) continue;
    const rs = e.getClientRects();
    for (let k = 0; k < rs.length; k++) if (rs[k].left >= c.left - 2 && rs[k].left < c.right - 2) return { para: i, frag: k }; }
  return { para: 0, frag: 0 };
}

function setView(v, instant) {
  R.view = clamp(v, 0, R.views - 1);
  const apply = () => { flow.style.transform = `translateX(${-R.view * (R.clipW + R.gap)}px)`; afterTurn(); };
  if (instant || matchMedia('(prefers-reduced-motion: reduce)').matches) return apply();
  flow.classList.add('turning');
  setTimeout(() => { apply(); flow.classList.remove('turning'); }, 120);
}

function colsBefore(si) {
  let sum = 0, chars = 0, cols = 0;
  RS().forEach((s, i) => { const k = R.knownCols.get(R.geoKey + '#' + i); if (k) { cols += k; chars += s.words; } });
  const perCol = cols ? chars / cols : Math.max(120, (R.colW * R.pageH) / (+S.fs * +S.fs * 2.9));
  for (let i = 0; i < si; i++) sum += R.knownCols.get(R.geoKey + '#' + i) || Math.ceil(RS()[i].words / perCol) + 1;
  return sum;
}

function afterTurn() {
  const b = R.book, isTitle = R.sec === SEC_TITLE;
  const c0 = R.view * R.per, before = isTitle ? 0 : colsBefore(R.sec);
  const s = isTitle ? null : RS()[R.sec];
  const hasHead = s && (s.label || s.title || s.part);
  const sides = R.spread ? [['L', c0], ['R', c0 + 1]] : [['R', c0]];
  $('#headL').textContent = $('#folioL').textContent = '';
  for (const [side, c] of sides) {
    const bare = isTitle || c >= R.cols || R.fullCols.has(c);
    const opening = c === 0 && hasHead;
    $('#head' + side).textContent = bare || opening ? '' : (side === 'L' ? b.title : secName(s, R.sec));
    $('#folio' + side).textContent = bare ? '' : String(before + c + 1);
  }
  if (!isTitle) {
    const { para, frag } = anchorPara();
    R.state.pos = { sec: R.sec, para, frag };
    const done = (s.start + s.cum[para]) / Math.max(1, b.totalWords);
    $('#threadFill').style.width = (done * 100).toFixed(2) + '%';
    $('#where').textContent = `${secName(s, R.sec)}, ${Math.round(done * 100)}% read`;
  } else { R.state.pos = { sec: SEC_TITLE, para: 0 }; $('#threadFill').style.width = '0%'; $('#where').textContent = 'Title page'; }
  $('#prev').disabled = isTitle && R.view === 0;
  saveState(); Studio.pump();
}

function openSection(si, where) {
  R.sec = clamp(si, SEC_TITLE, RS().length - 1);
  geometry(); buildSection(R.sec);
  flow.style.transform = 'translateX(0)';
  placePlates(); measureCols();
  let v = 0;
  if (where === 'end') v = R.views - 1;
  else if (where && typeof where === 'object') {
    const target = where.plate ? $(`[data-plate="${where.plate}"]`, flow) : R.paraEls[clamp(where.para || 0, 0, R.paraEls.length - 1)];
    if (target) v = viewOfEl(target, where.plate ? 0 : where.frag || 0);
  }
  setView(v, true);
}

function relayout() {                       // same place, new geometry or new plates
  if (!R.book) return;
  const pos = R.state.pos || { sec: SEC_TITLE, para: 0 };
  const atTitleFace = R.sec === SEC_TITLE;
  openSection(atTitleFace ? SEC_TITLE : pos.sec, atTitleFace ? (R.view ? 'end' : null) : { para: pos.para, frag: pos.frag });
}

function turn(d) {
  if (!$('#lightbox').hidden || !$('#drawer').hidden || !$('#studioDlg').hidden) return;
  if (d > 0) { if (R.view < R.views - 1) setView(R.view + 1); else if (R.sec < RS().length - 1) { flow.classList.add('turning'); setTimeout(() => { openSection(R.sec + 1); flow.classList.remove('turning'); }, 120); } }
  else { if (R.view > 0) setView(R.view - 1); else if (R.sec > SEC_TITLE) { flow.classList.add('turning'); setTimeout(() => { openSection(R.sec - 1, 'end'); flow.classList.remove('turning'); }, 120); } }
}

const saveState = debounce(() => { if (R.book) Store.put('states', { ...R.state, bookId: R.book.id }); }, 500);

/* a plate changed: repaint in place if it is on the page, otherwise nothing to do */
function refreshPlate(pl, relay) {
  if (!R.book || pl.bookId !== R.book.id) return;
  if (relay) { if (pl.sec === R.sec) relayout(); return; }
  const fig = $(`[data-plate="${pl.id}"]`, flow); if (!fig) return;
  const art = $('.art', fig); const old = $('img', art); if (old) old.remove();
  if (pl.status === 'done' && pl.img) art.prepend(el('img', { class: 'fresh', src: urlOf(pl), alt: pl.caption, draggable: 'false' }));
  paintWip(fig, pl);
}

/* ═════════ providers: who plans the scenes and who draws them ═════════
   Every provider exposes  plan(prompt, signal) -> object   and   draw({prompt,width,height,seed}, signal) -> Blob.
   Errors are thrown as { code, message } with code one of: config, auth, rate, refused, network, bad. */
const http = async (url, opts) => {
  try { return await fetch(url, opts); }
  catch (e) {
    if (e && e.name === 'AbortError') throw e;
    const t = window.__TAURI__ && window.__TAURI__.http;          // native fetch: no CORS, used only when the webview's own fetch fails
    if (t && t.fetch) return t.fetch(url, opts);
    throw e;
  }
};
const perr = (code, message) => ({ code, message });
async function check(res, who) {
  if (res.ok) return res;
  let detail = ''; try { detail = (await res.text()).slice(0, 300); } catch {}
  const s = res.status;
  if (s === 401 || s === 403) throw perr('auth', `${who} rejected the key (${s}). ${detail}`);
  if (s === 429) throw perr('rate', `${who} says slow down: the free allowance or rate limit is used up for now.`);
  if (s === 400 || s === 422) throw perr('refused', `${who} would not take that request (${s}). ${detail}`);
  throw perr('network', `${who} answered ${s}. ${detail}`);
}
function parseLoose(text) {
  if (text && typeof text === 'object') return text;
  const t = String(text || '').trim();
  const tries = [t, (t.match(/```(?:json)?\s*([\s\S]*?)```/) || [])[1], t.slice(t.indexOf('{'), t.lastIndexOf('}') + 1)];
  for (const c of tries) { if (!c) continue; try { return JSON.parse(c); } catch {} }
  throw perr('bad', 'The scene planner did not reply with usable JSON.');
}
const b64blob = (b64, type) => { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new Blob([u], { type: type || 'image/png' }); };
const asImage = async (res, who) => { const b = await res.blob(); if (!b.size || !/^image\//.test(b.type || 'image/')) throw perr('bad', `${who} did not send back an image.`); return b; };
const JSON_ONLY = 'You are a careful art director. Reply with only one valid JSON object and nothing else.';

const Providers = {
  cloudflare: {
    name: 'Cloudflare (free)',
    ready: () => /^https?:\/\/.+/.test(S.cfUrl.trim()) && S.cfKey.trim().length > 0,
    base: () => S.cfUrl.trim().replace(/\/+$/, ''),
    head: () => ({ 'Content-Type': 'application/json', Authorization: 'Bearer ' + S.cfKey.trim() }),
    async plan(prompt, signal) {
      const r = await check(await http(this.base() + '/plan', { method: 'POST', headers: this.head(), body: JSON.stringify({ prompt }), signal }), 'Your Cloudflare Worker');
      return parseLoose((await r.json()).text);
    },
    async draw(job, signal) {
      const r = await check(await http(this.base() + '/draw', { method: 'POST', headers: this.head(), body: JSON.stringify(job), signal }), 'Your Cloudflare Worker');
      return asImage(r, 'Your Cloudflare Worker');
    },
  },
  pollinations: {
    name: 'Pollinations (free, no setup)',
    ready: () => true,
    async plan(prompt, signal) {
      const key = S.polKey.trim();
      const url = key ? 'https://gen.pollinations.ai/v1/chat/completions' : 'https://text.pollinations.ai/openai';
      const headers = { 'Content-Type': 'application/json' }; if (key) headers.Authorization = 'Bearer ' + key;
      const r = await check(await http(url, { method: 'POST', headers, signal, body: JSON.stringify({ model: 'openai', private: true, messages: [{ role: 'system', content: JSON_ONLY }, { role: 'user', content: prompt }] }) }), 'Pollinations');
      const j = await r.json(); return parseLoose(j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content);
    },
    async draw({ prompt, width, height, seed }, signal) {
      const key = S.polKey.trim(), q = `model=flux&width=${width}&height=${height}&seed=${seed}&nologo=true&private=true&safe=true`;
      const p = encodeURIComponent(prompt.slice(0, 1500));
      const url = key ? `https://gen.pollinations.ai/image/${p}?${q}&key=${encodeURIComponent(key)}` : `https://image.pollinations.ai/prompt/${p}?${q}`;
      return asImage(await check(await http(url, { signal }), 'Pollinations'), 'Pollinations');
    },
  },
  gemini: {
    name: 'Google Gemini (paid)',
    ready: () => S.gemKey.trim().length > 0,
    url: m => `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(m.trim())}:generateContent`,
    head: () => ({ 'Content-Type': 'application/json', 'x-goog-api-key': S.gemKey.trim() }),
    async plan(prompt, signal) {
      const r = await check(await http(this.url(S.gemText), { method: 'POST', headers: this.head(), signal, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', temperature: 0.5 } }) }), 'Gemini');
      const j = await r.json(); const parts = j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts || [];
      return parseLoose(parts.map(p => p.text || '').join(''));
    },
    async draw({ prompt, width, height }, signal) {
      const r = await check(await http(this.url(S.gemImage), { method: 'POST', headers: this.head(), signal, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseModalities: ['TEXT', 'IMAGE'], imageConfig: { aspectRatio: width > height ? '3:2' : '3:4' } } }) }), 'Gemini');
      const j = await r.json(); const parts = j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts || [];
      const pic = parts.map(p => p.inlineData || p.inline_data).find(Boolean);
      if (!pic) throw perr(j.promptFeedback ? 'refused' : 'bad', 'Gemini did not send back an image.');
      return b64blob(pic.data, pic.mimeType || pic.mime_type);
    },
  },
  openai: {
    name: 'OpenAI (paid)',
    ready: () => S.oaKey.trim().length > 0,
    head: () => ({ 'Content-Type': 'application/json', Authorization: 'Bearer ' + S.oaKey.trim() }),
    async plan(prompt, signal) {
      const r = await check(await http('https://api.openai.com/v1/chat/completions', { method: 'POST', headers: this.head(), signal, body: JSON.stringify({ model: S.oaText.trim(), response_format: { type: 'json_object' }, messages: [{ role: 'system', content: JSON_ONLY }, { role: 'user', content: prompt }] }) }), 'OpenAI');
      const j = await r.json(); return parseLoose(j.choices[0].message.content);
    },
    async draw({ prompt, width, height }, signal) {
      const r = await check(await http('https://api.openai.com/v1/images/generations', { method: 'POST', headers: this.head(), signal, body: JSON.stringify({ model: S.oaImage.trim(), prompt, size: width > height ? '1536x1024' : '1024x1536', quality: 'medium', n: 1 }) }), 'OpenAI');
      const j = await r.json(); const d = j.data && j.data[0];
      if (d && d.b64_json) return b64blob(d.b64_json, 'image/png');
      if (d && d.url) return asImage(await http(d.url, { signal }), 'OpenAI');
      throw perr('bad', 'OpenAI did not send back an image.');
    },
  },
};
const provider = () => Providers[S.provider] || Providers.cloudflare;

/* The look of every plate. Kept short: the fast image models read only the first couple of hundred words. */
const STYLE = 'Graphite pencil sketch, a black and white book illustration in the manner of a nineteenth-century novel plate. Fine cross-hatching and soft tonal shading, confident searching linework, realistic human proportions, atmospheric light and shadow, drawn by hand on plain white paper, the edges left unfinished and fading into blank paper. Monochrome. No colour, no text, no lettering, no border, not a cartoon, not a doodle.';
const imagePrompt = pl => `${STYLE} ${pl.kind === 'inset' ? 'Wide composition with the subject in the central band.' : 'Upright composition.'} Scene: ${pl.brief}`.slice(0, 2000);
const SIZES = { full: [768, 1024], inset: [1152, 768] };

/* ═════════ the studio: plans scenes ahead of the reader, then draws them ═════════ */
const Studio = (() => {
  const A = { planning: null, drawing: new Map(), blocked: '', note: '', fails: 0, planTries: new Map() };
  const LOOKAHEAD = 4800;                   // words, about 16 pages
  const posWords = () => { const p = R.state.pos; if (!p || p.sec < 0) return 0; const s = RS()[p.sec]; return s.start + (s.cum[p.para] || 0); };
  const plateWords = pl => { const s = RS()[pl.sec]; return s.start + (s.cum[clamp(pl.para, 0, s.cum.length - 1)] || 0); };
  const ready = () => provider().ready();

  function nextWindow() {
    const here = posWords(), st = R.state.windows;
    const waiting = [...R.plates.values()].filter(p => p.status === 'planned' && plateWords(p) >= here).length;
    if (waiting >= 3) return null;
    const p = R.state.pos && R.state.pos.sec >= 0 ? R.state.pos : { sec: 0, para: 0 };
    for (let si = p.sec; si < RS().length; si++) for (const w of RS()[si].windows) {
      if (si === p.sec && w.to < p.para) continue;
      if (w.startWord > here + LOOKAHEAD) return null;
      if (!st[si + ':' + w.idx] && w.words >= 350) return w;
    }
    return null;
  }
  function nextPlate() {
    const here = posWords();
    const open = [...R.plates.values()].filter(p => p.status === 'planned' && !A.drawing.has(p.id));
    const ahead = open.filter(p => plateWords(p) >= here - 250 && plateWords(p) <= here + LOOKAHEAD + 3000).sort((a, b) => plateWords(a) - plateWords(b));
    if (ahead.length) return ahead[0];
    return open.filter(p => plateWords(p) < here && plateWords(p) > here - 3500).sort((a, b) => plateWords(b) - plateWords(a))[0] || null;
  }

  function pump() {
    if (R.book && ready() && S.paused !== '1' && !A.blocked) {
      const busy = () => (A.planning ? 1 : 0) + A.drawing.size;
      if (!A.planning && busy() < 2) { const w = nextWindow(); if (w) plan(w); }
      while (busy() < 2) { const p = nextPlate(); if (!p) break; draw(p); }
    }
    status();
  }

  function fail(e, what) {
    const code = e && e.code || 'network';
    if (code === 'auth' || code === 'config') { A.blocked = 'setup'; A.note = e.message || 'The studio needs setting up.'; }
    else if (code === 'rate') { A.blocked = 'retry'; A.note = e.message; }
    else { A.fails++; if (A.fails >= 2) { A.blocked = 'retry'; A.note = `${what} failed twice. ${e && e.message ? e.message : 'Check your connection.'}`; } }
  }

  /* ── planning ── */
  async function plan(w) {
    const book = R.book, s = RS()[w.sec], key = w.sec + ':' + w.idx, ctl = new AbortController();
    A.planning = { ctl, bookId: book.id };
    const count = clamp(Math.round(w.words / 3000 * +S.density), 1, 4);
    const passage = []; for (let i = w.from; i <= w.to; i++) if (s.paras[i].k === 'p') passage.push(`[${i}] ${s.paras[i].x}`);
    const earliest = w.sec === 0 && w.idx === 0 ? Math.min(w.from + 4, w.to) : w.from;
    const prompt = `You are the art director of an illustrated edition of a novel. Below is a passage, one paragraph per line, each starting with its paragraph number in square brackets.

Choose exactly ${count} moment${count > 1 ? 's' : ''} from this passage to illustrate with a pencil plate.
- Pick moments that are visual: a place seen for the first time, an arrival, a confrontation, a gesture, weather, a journey, a striking object or room. Avoid moments that are only talk or thought.
- Spread them through the passage. Do not pick anything before paragraph ${earliest}.
- Depict only what the book has established so far. Never anticipate later events.
- Nothing gory, sexual or otherwise unsuitable for a general illustrated edition; choose the quieter beat beside such a moment.

For each moment give:
  "para": the number of the paragraph in which the moment happens.
  "caption": a phrase copied word for word from that paragraph, at most 14 words.
  "kind": "full" for an upright full-page plate (figures, interiors, big scenes) or "inset" for a wide vignette (landscapes, streets, a coach, a table).
  "brief": 50 to 80 words that will be given to an image generator that knows nothing about the book. Purely visual and concrete, in plain descriptive sentences: the period and place; time of day, weather and where the light falls; each person in view described by appearance (apparent age, build, hair, clothing, taken from the cast notes) and never by name; their posture and what they are doing; what is in the foreground and background; the mood. No names, no plot, no dialogue.

Also return:
  "cast": short visual notes on recurring characters and places, as an object of name to one line (age, build, hair, face, usual dress). Start from the notes below, keep them consistent, add newcomers, at most 12 entries. Where the text is silent, infer period-appropriate dress and keep to it.
  "setting": one line giving period and locale as best you can tell.

Cast notes so far: ${JSON.stringify(R.state.cast || {})}
Setting so far: ${R.state.setting || 'unknown'}
Book: ${book.title}${book.author ? ' by ' + book.author : ''}${s.title || s.label ? '. Chapter: ' + secName(s, w.sec) : ''}

Reply with only JSON in this shape: {"scenes":[{"para":12,"caption":"...","kind":"full","brief":"..."}],"cast":{"Name":"..."},"setting":"..."}

PASSAGE
${passage.join('\n')}`.slice(0, 60000);
    status();
    try {
      const out = await provider().plan(prompt, ctl.signal);
      if (!R.book || R.book.id !== book.id) return;
      const scenes = Array.isArray(out && out.scenes) ? out.scenes : [];
      if (!scenes.length) throw perr('bad', 'The scene planner returned no scenes.');
      const taken = new Set(platesIn(w.sec).map(p => p.para)); let added = 0, lastKind = '';
      for (const sc of scenes.slice(0, 4)) {
        const para = clamp(parseInt(sc.para, 10), w.from, w.to);
        if (!Number.isFinite(para) || !sc.brief || [...taken].some(t => Math.abs(t - para) < 4)) continue;
        let kind = sc.kind === 'inset' ? 'inset' : 'full'; if (kind === lastKind && scenes.length > 1 && added) kind = kind === 'full' ? 'inset' : 'full'; lastKind = kind;
        const caption = String(sc.caption || '').replace(/\s+/g, ' ').trim().replace(/^[“"‘']+|[”"’']+$/g, '').slice(0, 120) || 'A scene from the chapter';
        const pl = { id: uid(), bookId: book.id, sec: w.sec, para, kind, caption, brief: String(sc.brief).replace(/\s+/g, ' ').slice(0, 900), status: 'planned', img: null, tries: 0, at: Date.now() };
        R.plates.set(pl.id, pl); Store.put('plates', pl); taken.add(para); added++;
      }
      if (out.cast && typeof out.cast === 'object') { const c = {}; for (const [k, v] of Object.entries(out.cast).slice(0, 12)) c[String(k).slice(0, 60)] = String(v).slice(0, 260); R.state.cast = c; }
      if (typeof out.setting === 'string') R.state.setting = out.setting.slice(0, 240);
      R.state.windows[key] = 'done'; A.fails = 0; saveState();
      if (added && w.sec === R.sec) relayout();
    } catch (e) {
      if (e && e.name !== 'AbortError' && R.book && R.book.id === book.id) {
        const n = (A.planTries.get(key) || 0) + 1; A.planTries.set(key, n);
        if ((e.code === 'bad' || e.code === 'refused') && n >= 2) { R.state.windows[key] = 'skipped'; saveState(); }   // move on rather than stall the book
        else fail(e, 'Planning the next plates');
      }
    } finally { if (A.planning && A.planning.ctl === ctl) A.planning = null; pump(); }
  }

  /* ── drawing ── */
  async function draw(pl) {
    const book = R.book, ctl = new AbortController();
    A.drawing.set(pl.id, ctl); pl.status = 'drawing'; refreshPlate(pl); status();
    try {
      const [width, height] = SIZES[pl.kind] || SIZES.full;
      const seed = ((book.seed || 1) + pl.para * 7919 + pl.sec * 104729 + (pl.tries || 0) * 15485863) % 2147483647;
      const blob = await provider().draw({ prompt: imagePrompt(pl), width, height, seed }, ctl.signal);
      pl.img = blob; pl.status = 'done'; pl.by = S.provider; A.fails = 0; dropUrl(pl.id);
    } catch (e) {
      if (e && e.name === 'AbortError') pl.status = 'planned';
      else { pl.status = 'failed'; pl.why = e && e.message || ''; if (!e || e.code !== 'refused') fail(e || {}, 'Drawing a plate'); }
    } finally {
      A.drawing.delete(pl.id); Store.put('plates', pl);
      refreshPlate(pl); fillIllus(); pump();
    }
  }

  function status() {
    const box = $('#studio'), msg = $('.msg', box), btn = $('button', box);
    btn.hidden = true; box.classList.remove('busy'); let t = '';
    if (!R.book) return;
    const here = posWords(), all = [...R.plates.values()];
    const waiting = all.filter(p => p.status === 'done' && plateWords(p) >= here).length;
    const act = (label, fn) => { btn.hidden = false; btn.textContent = label; btn.onclick = fn; };
    if (!ready()) { t = 'No one is drawing yet'; act('Set up the studio', () => openStudio()); }
    else if (A.blocked === 'setup') { t = A.note; act('Open the studio', () => openStudio()); }
    else if (A.blocked) { t = A.note; act('Carry on illustrating', resume); }
    else if (S.paused === '1') { t = 'Illustrating is paused'; act('Carry on', () => { S.paused = '0'; saveSettings(); syncPanel(); pump(); }); }
    else if (A.drawing.size) { const pl = R.plates.get([...A.drawing.keys()][0]); box.classList.add('busy'); t = `Sketching “${pl ? pl.caption : ''}”`; }
    else if (A.planning) { box.classList.add('busy'); t = 'Reading ahead for scenes to draw…'; }
    else t = waiting ? `${waiting} plate${waiting > 1 ? 's' : ''} waiting in the pages ahead` : (all.some(p => p.status === 'done') ? 'The plates ahead are all drawn' : '');
    msg.textContent = t; msg.title = t;
  }

  function resume() { A.blocked = ''; A.note = ''; A.fails = 0; pump(); }
  function stop() { if (A.planning) A.planning.ctl.abort(); for (const c of A.drawing.values()) c.abort(); }
  function redrawPlate(pl) { if (!ready() || A.drawing.has(pl.id)) return; pl.tries = (pl.tries || 0) + 1; if (A.blocked !== 'setup') A.blocked = ''; draw(pl); }
  return { pump, stop, status, resume, redrawPlate, get on() { return ready(); } };
})();

/* object URLs for plate images, made on demand and released when the book closes */
const urls = new Map();
const urlOf = pl => { if (!pl.img) return ''; if (!urls.has(pl.id)) urls.set(pl.id, URL.createObjectURL(pl.img)); return urls.get(pl.id); };
const dropUrl = id => { if (urls.has(id)) { URL.revokeObjectURL(urls.get(id)); urls.delete(id); } };
const dropAllUrls = () => { for (const id of [...urls.keys()]) dropUrl(id); };

function redraw(id) { const pl = R.plates.get(id); if (!pl) return; closeLightbox(); pl.img = null; dropUrl(id); Studio.redrawPlate(pl); }
function removePlate(id) { const pl = R.plates.get(id); if (!pl) return; pl.status = 'removed'; pl.img = null; dropUrl(id); Store.put('plates', pl); refreshPlate(pl, true); fillIllus(); }

/* ═════════ opening and closing books ═════════ */
async function openBook(id) {
  const book = await Store.get('books', id); if (!book) return renderShelf();
  indexBook(book);
  const st = (await Store.get('states', id)) || { bookId: id };
  st.windows = st.windows || {}; st.cast = st.cast || {}; st.pos = st.pos || { sec: SEC_TITLE, para: 0 };
  dropAllUrls(); R.book = book; R.state = st; R.plates = new Map(); R.knownCols = new Map();
  for (const p of await Store.platesOf(id)) { if (p.status === 'drawing') p.status = 'planned'; R.plates.set(p.id, p); }
  $('#library').hidden = true; $('#reader').hidden = false; $('#barTitle').textContent = book.title;
  document.title = book.title + ' · Marginalia';
  fillToc(); fillIllus(); syncPanel();
  openSection(st.pos.sec, st.pos.sec >= 0 ? { para: st.pos.para, frag: st.pos.frag } : null);
  Studio.resume();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => R.book === book && relayout());
}
function closeBook() {
  Studio.stop(); saveState(); closeOverlays(); dropAllUrls();
  R.book = null; $('#reader').hidden = true; $('#library').hidden = false; document.title = 'Marginalia: novels illustrated as you read';
  renderShelf();
}

async function importFile(file) {
  const say = t => { $('#importStatus').textContent = t; };
  if (!file) return;
  if (!/\.pdf$/i.test(file.name) && file.type !== 'application/pdf') return say('That is not a PDF. Choose a novel saved as a .pdf file.');
  $('#openBtn').disabled = true;
  try {
    say('Opening the book…');
    const book = await extractBook(file, (n, of) => say(`Reading page ${n} of ${of}…`));
    say('Binding it for the shelf…');
    const wc = book.sections.reduce((s, x) => s + x.paras.reduce((t, p) => t + (p.k === 'p' ? words(p.x) : 0), 0), 0);
    await Store.put('books', book);
    await Store.put('metas', { id: book.id, title: book.title, author: book.author, addedAt: book.addedAt, words: wc, chapters: book.sections.length });
    say(''); await openBook(book.id);
  } catch (e) { say(e && e.message ? e.message : 'That file could not be opened.'); }
  finally { $('#openBtn').disabled = false; $('#file').value = ''; }
}

async function renderShelf() {
  const list = $('#shelfList'); list.textContent = '';
  const metas = (await Store.all('metas')).sort((a, b) => b.addedAt - a.addedAt);
  if (!metas.length) return list.append(el('li', { class: 'empty', text: 'Nothing here yet. The novels you open are kept on this shelf, with their plates, in this browser.' }));
  for (const m of metas) {
    const st = await Store.get('states', m.id); const plates = (await Store.platesOf(m.id)).filter(p => p.status === 'done').length;
    const bits = [`${Math.round(m.words / 1000)}k words`, plates ? `${plates} plate${plates > 1 ? 's' : ''}` : 'no plates yet'];
    if (st && st.pos && st.pos.sec >= 0) bits.unshift('bookmarked');
    const rm = el('button', { class: 'rm', type: 'button', text: 'Remove' });
    rm.onclick = async () => { if (!rm.classList.contains('sure')) { rm.classList.add('sure'); rm.textContent = 'Remove book and plates?'; setTimeout(() => { rm.classList.remove('sure'); rm.textContent = 'Remove'; }, 3500); return; }
      for (const p of await Store.platesOf(m.id)) await Store.del('plates', p.id);
      await Store.del('books', m.id); await Store.del('metas', m.id); await Store.del('states', m.id); renderShelf(); };
    list.append(el('li', {}, el('button', { class: 'bk', type: 'button', onclick: () => openBook(m.id) },
      el('span', { class: 'bk-title', text: m.title }), m.author ? el('span', { class: 'bk-author', text: m.author }) : null, el('span', { class: 'bk-meta', text: bits.join(', ') })), rm));
  }
}

/* ═════════ contents, settings, lightbox ═════════ */
function fillToc() {
  const ol = $('#tocList'); ol.textContent = '';
  ol.append(el('li', {}, el('button', { type: 'button', onclick: () => { closeOverlays(); openSection(SEC_TITLE, R.spread ? 'end' : null); } }, el('span', { class: 'n', text: 'Title' }), el('span', { text: R.book.title }))));
  RS().forEach((s, i) => ol.append(el('li', { 'data-sec': i }, el('button', { type: 'button', onclick: () => { closeOverlays(); openSection(i); } },
    el('span', { class: 'n', text: s.label && s.title ? s.label : (s.auto ? 'Part ' + roman(i + 1) : '') }), el('span', { text: s.title || s.label || (s.auto ? firstWords(s) : 'Opening pages') })))));
}
const firstWords = s => { const p = s.paras.find(x => x.k === 'p'); return p ? p.x.split(/\s+/).slice(0, 6).join(' ') + '…' : ''; };
function fillIllus() {
  if (!R.book) return;
  const ol = $('#illusList'); ol.textContent = '';
  const done = [...R.plates.values()].filter(p => p.status === 'done').sort((a, b) => a.sec - b.sec || a.para - b.para);
  $('#illusNote').textContent = done.length ? '' : (Studio.on ? 'None yet. The first plates arrive within a minute or two of reading.' : 'Set up the studio and plates will be drawn as you read.');
  done.forEach((p, n) => ol.append(el('li', {}, el('button', { type: 'button', onclick: () => { closeOverlays(); openSection(p.sec, { plate: p.id }); } },
    el('span', { class: 'n', text: 'Plate ' + roman(n + 1) }), el('span', { class: 'cap', text: '“' + p.caption + '”' })))));
}
function closeOverlays() { $('#drawer').hidden = $('#panel').hidden = $('#scrim').hidden = true; }
function show(which) { closeOverlays(); $('#scrim').hidden = false; $(which).hidden = false;
  if (which === '#drawer') { $$('#tocList li').forEach(li => li.classList.toggle('here', +li.dataset.sec === R.sec)); const h = $('#tocList li.here'); if (h) h.scrollIntoView({ block: 'center' }); } }
function syncPanel() { for (const k of Object.keys(S)) { const i = $(`#panel input[name="${k}"][value="${S[k]}"]`); if (i) i.checked = true; } }

function openLightbox(id) {
  const pl = R.plates.get(id); if (!pl || pl.status !== 'done' || !pl.img) return;
  const lb = $('#lightbox'); lb.textContent = '';
  const sheet = el('div', { class: 'sheet' });
  const acts = el('div', { class: 'acts' }, el('button', { type: 'button', text: 'Close', onclick: closeLightbox }));
  if (Studio.on) acts.prepend(el('button', { type: 'button', text: 'Draw it again', onclick: () => redraw(id) }));
  sheet.append(el('div', { class: 'art' }, el('img', { src: urlOf(pl), alt: pl.caption })), el('div', { class: 'cap', text: '“' + pl.caption + '”' }), acts);
  sheet.onclick = e => e.stopPropagation(); lb.append(sheet); lb.hidden = false; $('button', acts).focus();
}
function closeLightbox() { $('#lightbox').hidden = true; }


/* ═════════ the studio dialog: choose and test who draws ═════════ */
const STUDIO_HELP = {
  cloudflare: 'Free. Runs on your own Cloudflare account through the small Worker in this project’s worker folder (ten minutes to set up, see the README). Paste the Worker’s address and the secret you chose.',
  pollinations: 'Free and needs nothing, but it is a shared community service: slower, rate-limited, and images may carry a small mark. A key from enter.pollinations.ai is optional.',
  gemini: 'Paid, a few cents a plate. Sharper drawing and better at following the scene. Uses your Google AI Studio key. Model names change; edit them if Google retires these.',
  openai: 'Paid. Uses your OpenAI key. Model names change; edit them if OpenAI retires these.',
};
function studioLine() {
  $('#fineprint').textContent = provider().ready()
    ? `Plates are drawn in pencil by ${provider().name.replace(/ \(.*/, '')} as you read. Passages go to that service so it can choose scenes; the book itself stays on this device.`
    : 'Set up the studio once and every novel you open is illustrated as you read. Until then this is a plain, handsome reader.';
}
function syncStudio() {
  const d = $('#studioDlg');
  for (const i of $$('input[data-k]', d)) { if (i.type === 'radio') i.checked = S[i.dataset.k] === i.value; else i.value = S[i.dataset.k] || ''; }
  for (const g of $$('[data-for]', d)) g.hidden = g.dataset.for !== S.provider;
  $('#studioHelp').textContent = STUDIO_HELP[S.provider] || '';
  studioLine();
}
function openStudio() { closeOverlays(); syncStudio(); $('#testOut').textContent = ''; $('#studioDlg').hidden = false; $('#studioScrim').hidden = false; }
function closeStudio() { $('#studioDlg').hidden = $('#studioScrim').hidden = true; if (R.book) Studio.resume(); }
$('#studioDlg').addEventListener('input', e => { const k = e.target.dataset.k; if (!k) return; S[k] = e.target.value; saveSettings(); if (k === 'provider') syncStudio(); else studioLine(); });
$('#studioBtn').onclick = openStudio; $('#studioFromPanel').onclick = openStudio;
$('#studioClose').onclick = closeStudio; $('#studioScrim').onclick = closeStudio;
$('#testBtn').onclick = async () => {
  const out = $('#testOut'), btn = $('#testBtn'); out.textContent = '';
  if (!provider().ready()) { out.textContent = 'Fill in the fields above first.'; return; }
  btn.disabled = true; out.append(el('span', { text: 'Drawing a test plate. This can take up to a minute…' }));
  const t0 = performance.now();
  try {
    const blob = await provider().draw({ prompt: imagePrompt({ kind: 'inset', brief: 'A lighthouse on a rocky headland at dusk in the 1880s, a cloaked figure with a lantern climbing the path toward it, heavy clouds, light from a low moon on the left, waves below.' }), width: 1152, height: 768, seed: 1880 });
    out.textContent = ''; const u = URL.createObjectURL(blob);
    out.append(el('div', { class: 'art test' }, el('img', { src: u, alt: 'Test plate' })), el('span', { text: `The studio works. That plate took ${Math.round((performance.now() - t0) / 1000)} seconds.` }));
  } catch (e) { out.textContent = e && e.message ? e.message : 'Could not reach the studio. Check the address and your connection.'; }
  finally { btn.disabled = false; }
};

/* ═════════ wiring ═════════ */
$('#openBtn').onclick = () => $('#file').click();
$('#file').onchange = e => importFile(e.target.files[0]);
addEventListener('dragover', e => { if ($('#library').hidden) return; e.preventDefault(); document.body.classList.add('dragging'); });
addEventListener('dragleave', e => { if (!e.relatedTarget) document.body.classList.remove('dragging'); });
addEventListener('drop', e => { e.preventDefault(); document.body.classList.remove('dragging'); if (!$('#library').hidden && e.dataTransfer.files[0]) importFile(e.dataTransfer.files[0]); });

$('#toShelf').onclick = closeBook;
$('#toContents').onclick = () => show('#drawer');
$('#toSettings').onclick = () => $('#panel').hidden ? show('#panel') : closeOverlays();
$('#scrim').onclick = closeOverlays;
$('[data-close]').onclick = closeOverlays;
$('#lightbox').onclick = closeLightbox;
$('#prev').onclick = () => turn(-1); $('#next').onclick = () => turn(1);
$('#panel').addEventListener('change', e => {
  const k = e.target.name; if (!(k in S)) return; S[k] = e.target.value; saveSettings(); applySettings();
  if (k === 'fs' || k === 'face') { relayout(); if (document.fonts) document.fonts.ready.then(relayout); } else Studio.pump();
});
flow.addEventListener('click', e => { const f = e.target.closest('.plate'); if (f && !e.target.closest('button')) openLightbox(f.dataset.plate); });
flow.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.classList.contains('plate')) openLightbox(e.target.dataset.plate); });
addEventListener('keydown', e => {
  if (e.key === 'Escape' && !$('#studioDlg').hidden) return closeStudio();
  if (!R.book) return;
  if (e.key === 'Escape') { closeLightbox(); closeOverlays(); closeStudio(); return; }
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.metaKey || e.ctrlKey || e.altKey) return;
  if (['ArrowRight', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); turn(1); }
  else if (['ArrowLeft', 'PageUp'].includes(e.key)) { e.preventDefault(); turn(-1); }
});
let sx = null, sy = 0;
bookEl.addEventListener('pointerdown', e => { if (e.pointerType !== 'mouse') { sx = e.clientX; sy = e.clientY; } });
bookEl.addEventListener('pointerup', e => { if (sx == null) return; const dx = e.clientX - sx, dy = e.clientY - sy; sx = null; if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.5 && !String(getSelection())) turn(dx < 0 ? 1 : -1); });
bookEl.addEventListener('pointercancel', () => { sx = null; });
addEventListener('resize', debounce(() => R.book && relayout(), 160));
addEventListener('pagehide', () => { if (R.book) Store.put('states', { ...R.state, bookId: R.book.id }); });

/* the shelf's own frontispiece, drawn with the same kit the plates use */
const HERO = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 800">
<path d="M46 70 L560 60 L556 300 L548 452 L44 470 L50 250Z" fill="url(#h1)"/>
<path d="M46 66 L560 60 L554 330 L300 250 L48 300Z" fill="url(#hc)" opacity=".85"/>
<path d="M250 60 L560 60 L556 200 L400 120Z" fill="url(#h2)" opacity=".8"/>
<path d="M404 178 L60 96 L52 206Z" fill="#ffffff" opacity=".78"/>
<path d="M412 178 L566 120 L566 214Z" fill="#ffffff" opacity=".7"/>
<path d="M92 236 C120 214 160 222 176 236 C204 224 246 232 258 252 C226 262 130 264 84 254Z" fill="#ffffff"/>
<path d="M98 250 C140 258 210 258 254 252" stroke="#777777" stroke-width="1.1"/>
<path d="M112 256 C150 264 200 262 236 258 L228 266 C190 270 150 270 120 264Z" fill="url(#h2)"/>
<path d="M300 300 C330 284 372 290 384 304 C350 312 320 312 292 308Z" fill="#ffffff"/>
<path d="M300 306 C330 312 360 310 382 305" stroke="#777777" stroke-width="1"/>
<circle cx="150" cy="158" r="50" fill="#ffffff" opacity=".8"/>
<path d="M126 150 C128 132 146 124 162 130 C178 136 182 158 170 172 C158 184 136 180 128 166" fill="#ffffff" stroke="#777777" stroke-width="1.2"/>
<path d="M150 146 C156 150 158 160 152 168" stroke="#aaaaaa" stroke-width="1"/>
<path d="M44 452 L352 440 L350 520 L44 548Z" fill="#ffffff"/>
<path d="M44 452 L352 440 L350 520 L44 548Z" fill="url(#hh)"/>
<path d="M44 452 L352 440 L350 520 L44 548Z" fill="url(#h1)"/>
<path d="M44 496 L340 482 L344 524 L44 548Z" fill="url(#h2)"/>
<path d="M46 452 C140 448 250 444 352 440" stroke="#777777" stroke-width="1"/>
<path d="M120 462 L186 460 M132 472 L172 471 M110 484 L196 481 M128 496 L180 494 M140 508 L170 507" stroke="#ffffff" stroke-width="3"/>
<path d="M60 476 C72 472 80 478 92 474 M220 470 C232 466 240 472 254 468 M70 512 C84 508 94 514 108 510 M236 500 C250 496 258 502 272 498 M270 478 C280 475 288 480 298 477" stroke="#444444" stroke-width="1"/>
<path d="M44 560 C120 528 200 500 290 470 C340 452 400 440 470 436 C510 434 540 440 560 446 L560 770 L44 770Z" fill="#ffffff"/>
<path d="M44 560 C120 528 200 500 290 470 C340 452 400 440 470 436 C510 434 540 440 560 446 L560 770 L44 770Z" fill="url(#st)"/>
<path d="M44 560 C120 528 200 500 290 470 C340 452 400 440 470 436 C510 434 540 440 560 446" stroke="#444444" stroke-width="1.4"/>
<path d="M44 562 C90 545 130 530 170 514 L178 548 C150 570 100 592 44 612Z" fill="url(#h3)"/>
<path d="M170 514 C210 498 250 484 290 470 L300 496 C262 514 220 530 178 548Z" fill="url(#h2)"/>
<path d="M96 546 L104 580 M130 532 L140 566 M196 506 L206 536 M240 490 L248 516" stroke="#1a1a1a" stroke-width="1.2"/>
<path d="M440 470 C480 500 520 560 560 640 L560 770 L380 770 C420 700 440 600 440 470Z" fill="url(#h2)"/>
<path d="M446 404 L446 438 L520 438 L520 404Z" fill="#ffffff"/>
<path d="M440 406 L482 380 L526 406Z" fill="#ffffff"/>
<path d="M440 406 L482 380 L526 406Z" fill="url(#h3)"/>
<path d="M486 406 L520 406 L520 438 L486 438Z" fill="url(#h2)"/>
<path d="M446 406 L446 438 M520 406 L520 439 M440 406 L482 380 L526 406 M444 438 L524 438" stroke="#1a1a1a" stroke-width="1.4"/>
<path d="M458 416 L470 416 L470 430 L458 430Z" fill="#ffffff" stroke="#1a1a1a" stroke-width="1"/>
<path d="M500 384 L500 370 L508 370 L508 392" fill="#ffffff" stroke="#1a1a1a" stroke-width="1.1"/>
<path d="M372 440 L385 214 L431 214 L444 440Z" fill="#ffffff"/>
<path d="M410 214 L431 214 L444 440 L416 440Z" fill="url(#hv)"/>
<path d="M424 214 L431 214 L444 440 L434 440Z" fill="url(#h2)"/>
<path d="M381 292 L435 292 L437 334 L379 334Z" fill="url(#h3)"/>
<path d="M377 368 L439 368 L441 404 L375 404Z" fill="url(#h2)"/>
<path d="M372 440 L378 330 M379 318 L385 214 M431 214 L437 322 M438 336 L444 440" stroke="#1a1a1a" stroke-width="1.6"/>
<path d="M400 246 L408 246 L408 262 L400 262Z M398 350 L406 350 L406 364 L398 364Z" fill="#1a1a1a"/>
<path d="M394 440 L394 414 C394 404 410 404 410 414 L410 440" fill="#444444" stroke="#1a1a1a" stroke-width="1.1"/>
<path d="M374 214 L442 214 L440 202 L376 202Z" fill="#ffffff" stroke="#1a1a1a" stroke-width="1.4"/>
<path d="M378 202 L378 190 M388 202 L388 190 M398 202 L398 190 M418 202 L418 190 M428 202 L428 190 M438 202 L438 190 M376 190 L440 190" stroke="#1a1a1a" stroke-width="1"/>
<path d="M392 202 L392 164 L424 164 L424 202Z" fill="#ffffff" stroke="#1a1a1a" stroke-width="1.3"/>
<path d="M400 164 L400 202 M408 164 L408 202 M416 164 L416 202" stroke="#444444" stroke-width="1"/>
<path d="M388 164 C392 142 424 142 428 164Z" fill="#ffffff"/>
<path d="M408 146 C420 148 426 156 428 164 L408 164Z" fill="url(#h3)"/>
<path d="M388 164 C392 142 424 142 428 164Z M408 146 L408 132 M404 132 L412 132" stroke="#1a1a1a" stroke-width="1.4"/>
<path d="M232 786 C250 700 300 640 340 580 C368 536 386 490 396 442 L410 442 C408 500 396 552 376 600 C350 660 330 720 330 786Z" fill="#ffffff"/>
<path d="M232 786 C250 700 300 640 340 580 C368 536 386 490 396 442" stroke="#444444" stroke-width="1.5"/>
<path d="M330 786 C330 720 350 660 376 600 C396 552 408 500 410 442" stroke="#444444" stroke-width="1.3"/>
<path d="M290 700 C300 696 312 698 320 694 M316 640 C326 636 336 638 344 634 M352 580 C360 577 368 578 374 575 M376 524 C382 522 388 523 392 521" stroke="#aaaaaa" stroke-width="1"/>
<path d="M300 770 C350 756 420 760 470 776 C420 790 340 788 300 770Z" fill="url(#h2)"/>
<g transform="translate(-99 -267) scale(1.35)">
<path d="M262 742 C256 718 252 690 258 664 C262 648 268 640 276 638 C288 636 298 646 302 664 C310 690 318 712 336 740 C312 748 284 748 262 742Z" fill="#ffffff"/>
<path d="M262 742 C256 718 252 690 258 664 C262 648 268 640 276 638 C288 636 298 646 302 664 C310 690 318 712 336 740 C312 748 284 748 262 742Z" fill="url(#h4)"/>
<path d="M286 640 C296 650 300 668 306 688 C312 708 322 726 336 740" fill="none" stroke="#1a1a1a" stroke-width="2.2"/>
<path d="M262 742 C256 718 252 690 258 664 C262 648 268 640 276 638" stroke="#1a1a1a" stroke-width="1.6"/>
<path d="M270 664 C272 690 270 716 274 742 M284 660 C288 690 290 716 296 744" stroke="#1a1a1a" stroke-width="1"/>
<path d="M268 626 C268 614 290 614 290 626 C290 636 284 642 279 642 C273 642 268 636 268 626Z" fill="#444444" stroke="#1a1a1a" stroke-width="1.3"/>
<path d="M258 622 C268 616 292 616 302 622 C292 627 268 627 258 622Z" fill="#1a1a1a"/>
<path d="M270 620 C271 606 288 606 289 620Z" fill="#1a1a1a"/>
<path d="M272 744 L270 760 L262 764 M292 746 L294 762 L304 765" stroke="#1a1a1a" stroke-width="2.4"/>
<path d="M300 668 C312 676 320 684 328 694" stroke="#1a1a1a" stroke-width="2.2"/>
<circle cx="332" cy="712" r="20" fill="#ffffff" opacity=".85"/>
<path d="M326 700 L338 700 L340 722 L324 722Z" fill="#ffffff" stroke="#1a1a1a" stroke-width="1.4"/>
<path d="M328 696 C330 690 334 690 336 696 M332 700 L332 722 M324 722 L340 722" stroke="#1a1a1a" stroke-width="1.2"/>
</g>
<path d="M44 770 L44 690 C70 676 100 684 120 700 C150 690 180 706 196 730 C210 748 214 762 216 770Z" fill="#ffffff"/>
<path d="M44 770 L44 690 C70 676 100 684 120 700 C150 690 180 706 196 730 C210 748 214 762 216 770Z" fill="url(#h4)"/>
<path d="M44 690 C70 676 100 684 120 700 C150 690 180 706 196 730 C210 748 214 762 216 770 M120 700 C112 720 116 744 110 768 M70 690 C76 712 66 740 72 766" stroke="#1a1a1a" stroke-width="1.8"/>
<path d="M420 770 C430 736 460 716 496 722 C520 706 548 712 560 726 L560 770Z" fill="#ffffff"/>
<path d="M420 770 C430 736 460 716 496 722 C520 706 548 712 560 726 L560 770Z" fill="url(#h3)"/>
<path d="M420 770 C430 736 460 716 496 722 C520 706 548 712 560 726 M496 722 C490 740 494 756 488 770" stroke="#1a1a1a" stroke-width="1.7"/>
<path d="M226 770 L222 752 M230 770 L232 748 M236 770 L242 754 M340 776 L338 758 M346 776 L350 756 M352 776 L360 762 M200 640 L196 624 M204 640 L206 620 M208 640 L214 626 M404 640 L402 624 M408 640 L412 622 M414 640 L420 628 M160 620 L156 606 M164 620 L166 602 M168 620 L174 608 M450 560 L448 546 M454 560 L458 544 M330 520 L328 508 M334 520 L338 506 M480 640 L478 624 M484 640 L490 626" stroke="#1a1a1a" stroke-width="1.1"/>
<path d="M300 560 L296 548 M304 560 L308 546 M250 600 L246 588 M254 600 L260 588 M420 520 L418 510 M424 520 L428 508 M500 500 L498 490 M504 500 L508 490" stroke="#444444" stroke-width="1"/>
<path d="M250 130 C256 124 260 124 264 130 C268 124 272 124 278 130 M300 170 C305 165 308 165 311 170 C314 165 317 165 322 170 M222 186 C226 182 229 182 232 186 C235 182 238 182 242 186" stroke="#444444" stroke-width="1.2"/>
</svg>`;
function mountHero() { const clean = sanitizeSvg(HERO, 'full'); if (clean) $('#heroArt').append(plateSvg(clean.markup, 'full', 'A cloaked figure with a lantern climbs a headland path toward a lighthouse under the moon')); }

/* ═════════ go ═════════ */
(async () => { mountHero(); syncStudio(); await Store.open(); await renderShelf(); })();

/* test hooks (harmless in production) */
window.__marginalia = { R, S, Providers, openBook, importFile };
})();
