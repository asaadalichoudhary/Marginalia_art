// The whole app lives in the web layer (../src). The native shell only opens the
// window and lends the page a native HTTP client, used as a fallback for services
// that refuse browser-style (CORS) requests.
#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_http::init())
        .run(tauri::generate_context!())
        .expect("error while running Marginalia");
}
